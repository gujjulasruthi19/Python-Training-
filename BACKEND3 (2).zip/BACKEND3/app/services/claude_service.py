
def call_claude_ai(prompt: str):
    return f"Claude response for: {prompt}"
