
def call_open_ai(prompt: str):
    return f"OpenAI response for: {prompt}"
