
def call_gemini_ai(prompt: str):
    return f"Gemini response for: {prompt}"
