
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.models import PromptRequest
from app.services.openai_service import call_open_ai
from app.services.claude_service import call_claude_ai
from app.services.gemini_service import call_gemini_ai

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/ask")
async def ask_ai(request: PromptRequest):
    return {
        "openai": call_open_ai(request.prompt),
        "claude": call_claude_ai(request.prompt),
        "gemini": call_gemini_ai(request.prompt)
    }
